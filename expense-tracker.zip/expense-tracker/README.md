﻿# Expense Tracker

A simple full-stack web application for tracking personal expenses.

## Features

* Add a new expense
* View all expenses
* View a single expense
* Edit an expense
* Delete an expense
* Filter expenses by category
* Display total amount
* Display number of expenses
* Display highest expense
* Form validation
* Responsive design for desktop and mobile
* Loading spinner while data is loading
* Bootstrap alerts for errors and success messages

## Technologies

### Frontend

* HTML
* CSS
* JavaScript
* Bootstrap 5
* Fetch API

### Backend

* Node.js
* Express.js
* PostgreSQL
* pg
* dotenv
* CORS

## Project Structure

```text
expense-tracker/
│
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
│
├── backend/
│   ├── controllers/
│   │   ├── expenseController.js
│   │   └── categoryController.js
│   ├── routes/
│   │   ├── expenseRoutes.js
│   │   └── categoryRoutes.js
│   ├── db.js
│   ├── server.js
│   ├── schema.sql
│   ├── package.json
│   ├── package-lock.json
│   └── .env.example
│
└── README.md
```

## Database Setup

1. Create a PostgreSQL database named:

```text
expense_tracker
```

2. Open the PostgreSQL Query Tool.

3. Run the `backend/schema.sql` file.

The database contains two main tables:

* `expenses`
* `categories`

The available categories are:

* Food
* Transport
* Bills
* Entertainment
* Other

## Environment Variables

Inside the `backend` folder, create a `.env` file:

```env
DB_USER=postgres
DB_HOST=localhost
DB_NAME=expense_tracker
DB_PASSWORD=YOUR_POSTGRES_PASSWORD
DB_PORT=5432
```

Do not upload the `.env` file.

## Install Backend Packages

Open a terminal inside the `backend` folder:

```bash
npm install
```

## Run the Backend

Inside the `backend` folder:

```bash
node server.js
```

The backend runs on:

```text
http://localhost:3000
```

## Run the Frontend

Open another terminal inside the `frontend` folder:

```bash
npx http-server
```

Then open the URL shown in the terminal, for example:

```text
http://127.0.0.1:8080
```

## API Endpoints

| Method | Endpoint                | Description         |
| ------ | ----------------------- | ------------------- |
| GET    | `/api/expenses`         | Get all expenses    |
| GET    | `/api/expenses/:id`     | Get one expense     |
| GET    | `/api/expenses/summary` | Get expense summary |
| POST   | `/api/expenses`         | Add an expense      |
| PUT    | `/api/expenses/:id`     | Update an expense   |
| DELETE | `/api/expenses/:id`     | Delete an expense   |
| GET    | `/api/categories`       | Get categories      |

## Validation

The backend validates:

* Title is required
* Amount must be greater than 0
* Amount must be a valid number
* Category must exist
* Expense date is required
* Invalid or non-existing expense IDs return `404`
* Invalid expense data returns `400`

All SQL queries use parameters to prevent SQL injection.

## Responsive Design

The application is responsive and can be used on:

* Desktop
* Tablet
* Mobile

CSS Grid is used for the summary cards.

## Screenshots

### Expense Tracker Dashboard

*Add screenshot here.*

### Add Expense

*Add screenshot here.*

### Edit Expense

*Add screenshot here.*

### Filter Expenses

*Add screenshot here.*

### Mobile View

*Add screenshot here.*

## Hardest Challenge

One of the challenges was handling the relationship between the `expenses` and `categories` tables.

The `expenses` table uses `category_id` as a foreign key that references the `categories` table. This required validating the category before inserting or updating an expense and maintaining the correct relationship between the two tables.

Another challenge was making sure the frontend handled API errors correctly. The application checks the HTTP response and displays the server error message using a Bootstrap alert.

## Testing

The API endpoints were tested using Thunder Client.

The following cases were tested:

* Successful GET request
* Successful POST request
* Successful PUT request
* Successful DELETE request
* Successful GET by ID
* Invalid expense data
* Invalid expense ID
* Non-existing expense ID

## Notes

The `.env` file and `node_modules` folder should not be included in the final ZIP submission.
