﻿# Expense Tracker

A simple web application for managing personal expenses.

## Features

* Add expenses
* View expenses
* Edit expenses
* Delete expenses
* Filter expenses by category
* View expense summary
* Form validation
* Loading spinner
* Success and error alerts
* Responsive design

## Technologies

### Frontend

* HTML
* CSS
* JavaScript
* Bootstrap 5
* Fetch API

### Backend

* Node.js
* Express.js
* PostgreSQL
* pg
* dotenv
* CORS

## Project Structure

```text
expense-tracker/
│
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
│
├── backend/
│   ├── controllers/
│   ├── routes/
│   ├── db.js
│   ├── server.js
│   ├── schema.sql
│   ├── package.json
│   ├── package-lock.json
│   └── .env.example
│
└── README.md
```

## Database Setup

Create a PostgreSQL database called:

```text
expense_tracker
```

Then run the `backend/schema.sql` file.

The database contains:

* `expenses`
* `categories`

Categories:

* Food
* Transport
* Bills
* Entertainment
* Other

## Environment Variables

Create a `.env` file inside the `backend` folder:

```env
DB_USER=postgres
DB_HOST=localhost
DB_NAME=expense_tracker
DB_PASSWORD=YOUR_POSTGRES_PASSWORD
DB_PORT=5432
```

Do not upload the `.env` file to GitHub.

## Installation

Open a terminal inside the `backend` folder and run:

```bash
npm install
```

## Run the Backend

```bash
node server.js
```

The backend runs on:

```text
http://localhost:3000
```

## Run the Frontend

Inside the `frontend` folder:

```bash
npx http-server
```

Then open the URL shown in the terminal.

## API Endpoints

| Method | Endpoint                | Description         |
| ------ | ----------------------- | ------------------- |
| GET    | `/api/expenses`         | Get all expenses    |
| GET    | `/api/expenses/:id`     | Get one expense     |
| GET    | `/api/expenses/summary` | Get expense summary |
| POST   | `/api/expenses`         | Add an expense      |
| PUT    | `/api/expenses/:id`     | Update an expense   |
| DELETE | `/api/expenses/:id`     | Delete an expense   |
| GET    | `/api/categories`       | Get categories      |

## Validation

The application validates:

* Required fields
* Expense amount
* Category
* Expense date
* Expense ID

Invalid requests return appropriate error responses.

## Responsive Design

The application works on:

* Desktop
* Tablet
* Mobile

## Screenshots

### Dashboard

Add screenshot here.

### Add Expense

Add screenshot here.

### Edit Expense

Add screenshot here.

### Filter

Add screenshot here.

## Testing

The API was tested using Thunder Client.

Tested operations include:

* GET
* POST
* PUT
* DELETE
* Get expense by ID
* Validation errors
* Invalid IDs

## Notes

Do not include `.env` or `node_modules` in the final project submission.

## Live Demo

https://ayatmatar.github.io/expense_tracker/
